module.exports={
    MONGOURI:process.env.MOGOURI,
    JWT_SECRET:process.env.JWT_SEC,
}