// const passwordReset = require("./routes/passwordReset");
const express = require('express')
const userRouter = require("./routes/userRoutes")
const expertRouter = require("./routes/expertProfile")
const app = express()
app.use(express.json())
app.use("/connpsych/users",userRouter)
app.use("/connpsych/experts",expertRouter)

//app.use("/api/password-reset", passwordReset);

module.exports = app
