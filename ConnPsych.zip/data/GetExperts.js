const Expert = require("../models/expertProfile");
const getAllExperts = async(req,res)=>{
    try{
        allExperts=await Expert.find()
        res.status(200).json({
            status:"success",
            Experts:allExperts
        })
    }
    
    catch(e){
        res.status(400).json({
            status:"Failed to get all experts"
        })   
    }
}
module.exports={
    getAllExperts
}