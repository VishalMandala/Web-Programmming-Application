export class Login {
  email = null;
  password = null;
}
