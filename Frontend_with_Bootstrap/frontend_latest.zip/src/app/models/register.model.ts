export class registerPatient {
  firstName = null;
  lastName = null;
  email = null;
  password = null;
  age = null;
  gender = null;
  city = null;
  state = null;
}

export class registerExpert {
  name = null;
  email = null;
  password = null;
  qualification = null;
  status = null;
  specialization = null;
}
